package com.example.macstudent.login;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnLogin, btnRegister;
    EditText edtEmail, edtPassword;
    DBHelper dbHelper;
    SQLiteDatabase ParkingDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);

        btnRegister = findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);

        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);

        dbHelper = new DBHelper(this);

    }

    @Override
    public void onClick(View view) {
        if (view.getId() == btnLogin.getId()){

            String username = edtEmail.getText().toString();
            String password = edtPassword.getText().toString();
            if (verifyLogin()){
                Toast.makeText(this, "Login Sucessful", Toast.LENGTH_LONG).show();


                finish();
                startActivity(new Intent(this,HomeActivity.class));
            }else{
                Toast.makeText(this, "Invalid Email/Password", Toast.LENGTH_LONG).show();
            }

        }else if(view.getId() == btnRegister.getId()){
            Toast.makeText(this, "Register Clicked", Toast.LENGTH_LONG).show();
            Intent signUpIntent = new Intent(this, SignUpActivity.class);

            startActivity(signUpIntent);

        }
    }

    private boolean verifyLogin() {
        try {

            ParkingDB = dbHelper.getReadableDatabase();
            String columns[] = {"Email", "Password"};
            String userData[] = {edtEmail.getText().toString(), edtPassword.getText().toString()};
            Cursor cursor = ParkingDB.query("UserInfo", columns, "Email = ? AND Password = ?", userData,null, null,null);
            if(cursor != null){
                if(cursor.getCount() > 0){
                    return true;
                }
            }
            return false;


        }catch (Exception e){
            Log.e("LoginActivity", e.getMessage());
            return false;
        }finally {
            ParkingDB.close();
        }
    }
}
